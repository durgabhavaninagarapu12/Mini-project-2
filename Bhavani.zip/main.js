db.students.insertMany([
  { id: 1, name: 'Bhavani', gender: 'M' },
  { id: 2, name: 'Joanna', gender: 'F' }
]);
db.students.find({ gender: 'F' });